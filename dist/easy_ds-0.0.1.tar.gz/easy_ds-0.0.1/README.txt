Implementations of Data Structures
- Singly Linked List
- Doubly Linked List
- Binary Tree
Different operations can be performed